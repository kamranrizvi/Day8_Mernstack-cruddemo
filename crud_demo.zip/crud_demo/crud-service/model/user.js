import mongoose from 'mongoose';
import autoIncrement from 'mongoose-auto-increment';

//const constant = require("../constants/regEx");

// how our document look like
// const userSchema = mongoose.Schema({
//     name: {type:String,required:'This field is required..'},
//     username: {type:String,required:'This field is required..'},
//     email: {type:String,required:'This field is required..'},
//     phone: {type:Number,required:'This field is required..'}
// });

const userSchema=mongoose.Schema({
    name:String,
    username:String,
    email:String,
    phone:Number
});



autoIncrement.initialize(mongoose.connection);
userSchema.plugin(autoIncrement.plugin, 'user');
// we need to turn it into a model
//Validation
const postUser = mongoose.model('user', userSchema);
userSchema.path('name').validate((val)=>{
    return constant.Constants.fullnameRegEx.test(val);;
}, 'Invalid Full Name.');
userSchema.path('username').validate((val)=>{
    return constant.Constants.usernameRegex.test(val);;
}, 'Invalid user Name.');
userSchema.path('email').validate((val)=>{
    return constant.Constants.emailRegex.test(val);;
}, 'Invalid Email ID.');
userSchema.path('phone').validate((val)=>{
    return constant.Constants.numberRegex.test(val);;
}, 'Invalid Contact Number.');

//mongoose.model('User', userSchema);

export default postUser;